#!/bin/bash


phantomjs --proxy-type=none appd-sc-home-init-01.js
sleep 1s
