#!/bin/bash

while true
do
    phantomjs --proxy-type=none appd-sc-search-aston.js	
    phantomjs --proxy-type=none appd-sc-search-bmw.js
	phantomjs --proxy-type=none appd-sc-search-ferrari.js
    phantomjs --proxy-type=none appd-sc-search-jaguar.js
    phantomjs --proxy-type=none appd-sc-search-lamborghini.js
    phantomjs --proxy-type=none appd-sc-search-lotus.js
    phantomjs --proxy-type=none appd-sc-search-mercedes.js
    phantomjs --proxy-type=none appd-sc-search-porsche.js
    phantomjs --proxy-type=none appd-sc-search-all.js
    phantomjs --proxy-type=none appd-sc-search-aston.js
    phantomjs --proxy-type=none appd-sc-search-aston.js
    phantomjs --proxy-type=none appd-sc-search-all.js
    phantomjs --proxy-type=none appd-sc-search-ferrari.js
    phantomjs --proxy-type=none appd-sc-search-ferrari.js
    phantomjs --proxy-type=none appd-sc-search-mercedes.js
    phantomjs --proxy-type=none appd-sc-search-mercedes.js
    phantomjs --proxy-type=none appd-sc-search-mercedes.js
    sleep 6s
done