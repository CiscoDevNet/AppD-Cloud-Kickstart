#!/bin/bash


phantomjs --proxy-type=none appd-sc-mem-leak-insurance-stop.js
sleep 1s
